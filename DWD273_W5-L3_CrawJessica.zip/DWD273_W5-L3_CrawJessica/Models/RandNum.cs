﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DWD273_W5_L3_CrawJessica.Models
{
    public class RandNum
    {
        
        public int Id { get; set; }
        public int LgRandNumA { get; set; }
        public int LgRandNumB { get; set; }
        public int LgRandNumC { get; set; }
        public int LgRandNumD { get; set; }
        public int LgRandNumE { get; set; }
        public int SmRandNum { get; set; }
    }
}